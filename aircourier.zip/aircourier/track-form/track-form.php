
<?php require_once("config.php");

include(TEMPLATE_FRONT . DS . "theader.php");

include "../config/database.php";

$tid = $_GET['track'];

$sql= "SELECT * FROM track WHERE pid = '$tid'";
			  $result = mysqli_query($link,$sql);
			  if(mysqli_num_rows($result) > 0){
				$row = mysqli_fetch_assoc($result);

				$row['email'];
				if(isset($row['location'])){

					$location = $row['location'];
				}

			  }

 ?>

 <!--================================
         START SLIDER AREA
     =================================-->
     <section class="breadcrumb">

         <div class="breadcrumb_content">
             <!-- container starts -->
             <div class="container">
                 <!-- row starts -->
                 <div class="row">
                     <!-- col-md-12 starts -->
                     <div class="col-md-12">
                         <div class="breadcrumb_title_wrapper">
                             <div class="page_title">
                                 <h1>Track Result Page</h1>
                             </div>
                             <ul class="bread_crumb">
                                 <li><a href="index.php">Home</a></li>
                                 <li class="bread_active">Track</li>





                             </ul>
                         </div>
                     </div><!-- col-md-12 ends -->
                 </div>
                 <!-- /.row ends -->
             </div><!-- /.container ends -->
         </div>

         <!-- menu starts -->
         <div class="menu_area">

             <!-- container starts -->
             <div class="container">
                 <!-- row start -->
                 <div class="row">
                     <div class="col-md-12">
                         <div class="mainmenu nav_shadow">
                             <nav class="navbar navbar-default">
                                 <!-- Brand and toggle get grouped for better mobile display -->
                                 <div class="navbar-header">
                                     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                         <span class="sr-only">Toggle navigation</span>
                                         <span class="icon-bar"></span>
                                         <span class="icon-bar"></span>
                                         <span class="icon-bar"></span>
                                     </button>
                                 </div>

                                 <!-- Collect the nav links, forms, and other content for toggling -->
                                 <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                     <ul class="nav navbar-nav magic_menu">
                                        	<li class="active"><a href="../index.php">Home</a></li>
                                         <li><a href="../track-form/index.php">Track another Shipment</a></li>
                                         <!--<li><a href="contact.php">contact</a></li>-->

                                     </ul>

                                 </div><!-- /.navbar-collapse -->
                             </nav>
                         </div><!-- main menu ends -->
                     </div>
                 </div><!-- /.row end -->

             </div><!-- /.container ends -->
         </div><!-- menu ends -->
     </section>
     <!--================================
         END SLIDER AREA
     =================================-->



 <!doctype html>
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

 <html>
 <head>
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <meta name="keywords" content="" />
 <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
 <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
 </head>
 <body>

     </br></br>


 <div class="container" >





                                 	<?php

 			$sql= "SELECT * FROM track WHERE pid = '$tid'";
 			  $result = mysqli_query($link,$sql);
 			  if(mysqli_num_rows($result) > 0){
 				$row = mysqli_fetch_assoc($result);

 				$row['email'];
 				if(isset($row['location'])){

 					$location = $row['location'];
 				}

 			  }

 				  ?>



 	<div class="content1" style="background-color:#148afd">
 		<h2>Order Tracking: <?php echo $row['pid'];?></h2>
 	</div>
 	<div class="content2" style="background-color:#e8fafc">
 		<div class="content2-header1">
 			<p>Expected delivery date : <span><?php echo $row['edd'];?></span></p>
 		</div>
 		<div class="content2-header1">
 			<p>Status : <span><?php echo $row['status'];?></span></p>
 		</div>
 		<div class="content2-header1">
 			<p>Date Shipped : <span><?php echo $row['shipdate'];?></span></p>
 		</div>
 		<div class="clear"></div>
 	</div>






 	<?php

 			$sql= "SELECT * FROM track WHERE pid = '$tid'";
 			  $result = mysqli_query($link,$sql);
 			  if(mysqli_num_rows($result) > 0){
 				$row = mysqli_fetch_assoc($result);

 				$row['status'];

 				 // if confirmed
 				if(isset($row['status']) && $row['status'] == "confirm" ){



 	     $confirm  =     ' <div class="confirm">
                 <div class="imgcircle" style="background-color:#148afd">
                 <img src="../images/confirm.png" alt="confirm order" style="display:"  >
             	</div>
 				<span class="line"></span>
 				<p  style="">Confirmed </p>
 			    </div>';


 				}

 				// if processed

 				if(isset($row['status']) && $row['status'] == "process"  ){

 			 $confirm  =   ' <div class="confirm">

                 <div class="imgcircle" style="background-color:#148afd">
                 <img src="../images/confirm.png" alt="confirm order" style="display:"  >
             	</div>
 				<span class="line"></span>
 				<p  style="">Confirmed </p>
 			    </div>



 			    <div class="process">
            	 	<div class="imgcircle" style="background-color:#148afd">
                 	<img src="../images/process.png" alt="process order" style="display:non">
             	</div>
 				<span class="line"></span>
 				<p style="display:non">Processing</p>
 			</div>


 			    ';


 				}


 				// if dispatched

 				if(isset($row['status']) && $row['status'] == "dispatch" ){




 				    $confirm  =   ' <div class="confirm">

                 <div class="imgcircle" style="background-color:#148afd">
                 <img src="../images/confirm.png" alt="confirm order" style="display:"  >
             	</div>
 				<span class="line"></span>
 				<p  style="">Confirmed </p>
 			    </div>



 			    <div class="process">
            	 	<div class="imgcircle" style="background-color:#148afd">
                 	<img src="../images/process.png" alt="process order" style="display:non">
             	</div>
 				<span class="line"></span>
 				<p style="display:non">Processing</p>
 			</div>



 			    	<div class="quality">
 				<div class="imgcircle" style="background-color:#148afd">
                   <img src="../images/quality.png" alt="quality check" style="display:non">
             	</div>
 				<span class="line"></span>
 				<p style="display:non"> Quality</p>
 			</div>



 			    <div class="dispatch">
 				<div class="imgcircle" style="background-color:blue">
                 	<img src="../images/dispatch.png" alt="dispatch product" style="display:non">
             	</div>
 				<span class="line"></span>
 				<p style="display:non">Dispatched</p>
 			</div>

 			    ';



 				}





 				// if quality checked




 				if(isset($row['status']) && $row['status'] == "quality" ){


 				    $confirm  =   ' <div class="confirm">

                 <div class="imgcircle" style="background-color:#148afd">
                 <img src="../images/confirm.png" alt="confirm order" style="display:"  >
             	</div>
 				<span class="line"></span>
 				<p  style="">Confirmed </p>
 			    </div>



 			    <div class="process">
            	 	<div class="imgcircle" style="background-color:#148afd">
                 	<img src="../images/process.png" alt="process order" style="display:non">
             	</div>
 				<span class="line"></span>
 				<p style="display:non">Processing</p>
 			</div>



 			    	<div class="quality">
 				<div class="imgcircle" style="background-color:#148afd">
                 <img src="../images/quality.png" alt="quality check" style="display:non">
             	</div>
 				<span class="line"></span>
 				<p style="display:non"> Quality </p>
 			</div>
 			    ';

 				}

 				// if delivered


 				if(isset($row['status']) && $row['status'] == "deliver" ){



 				    $confirm  =   ' <div class="confirm">

                 <div class="imgcircle" style="background-color:#148afd">
                 <img src="../images/confirm.png" alt="confirm order" style="display:"  >
             	</div>
 				<span class="line"></span>
 				<p  style="">Confirmed </p>
 			    </div>



 			    <div class="process">
            	 	<div class="imgcircle" style="background-color:#148afd">
                 	<img src="../images/process.png" alt="process order" style="display:non">
             	</div>
 				<span class="line"></span>
 				<p style="display:non"> Processing</p>
 			</div>



 			    	<div class="quality">
 				<div class="imgcircle" style="background-color:#148afd">
                   <img src="../images/quality.png" alt="quality check" style="display:non">
             	</div>
 				<span class="line"></span>
 				<p style="display:non"> Quality</p>
 			</div>



 			    <div class="dispatch">
 				<div class="imgcircle" style="background-color:blue">
                 	<img src="../images/dispatch.png" alt="dispatch product" style="display:non">
             	</div>
 				<span class="line"></span>
 				<p style="display:non">Dispatched</p>
 			</div>

 	<div class="delivery">
 				<div class="imgcircle" style="background-color:blue">
                 	<img src="../images/delivery.png" alt="delivery" style="display:non">
 				</div>
 				<p style="display:non"> Delivered</p>
 			</div>
 			';
 				}


 			  }

 				  ?>

 	<div class="content3">
         <div class="shipment">
 		 <?php echo $confirm ;?>




 			<div class="clear"></div>
 		</div>
 	</div>
 </div>





































































 <div class="container">
     <div class="row">
         <div class="col-xs-12">
             <?php

 			$sql= "SELECT * FROM track WHERE pid = '$tid'";
 			  $result = mysqli_query($link,$sql);
 			  if(mysqli_num_rows($result) > 0){
 				$row = mysqli_fetch_assoc($result);

 				$row['email'];
 				if(isset($row['location'])){

 					$location = $row['location'];
 				}

 			  }

 				  ?>


             <hr>
             <div class="row" >
                 <div class="col-xs-12 col-md-4 col-lg-4 pull-left" >
                     <div class="panel panel-default height" style="background-color:#e8fafc">
                         <div class="panel-heading" style="color:#fff; background-color:#148afd">Shipment Details</div>
                         <div class="panel-body" style="background-color:#e8fafc">
                             <strong>Quantity : </strong> <?php echo $row['qty'];?> <br>
                            <br>


                             <strong>Weight : </strong> <?php echo $row['weight'];?><br>
                             <br>
                             <strong>Service Type : </strong>  <?php echo $row['servicetype'];?>
                                  <br>

                             <br>
                             <strong>Description : </strong>  <?php echo $row['pdesc'];?>
                         </div>
                     </div>
                 </div>

                 <div class="col-xs-12 col-md-4 col-lg-4">
                     <div class="panel panel-default height" style="background-color:#e8fafc">
                         <div class="panel-heading" style="color:#fff; background-color:#148afd" >Destination</div>
                         <div class="panel-body">
                            <strong>Receiver Name : </strong> <?php echo $row['rname'];?> <br>
                            <br>


                             <strong>Receiver Email : </strong> <?php echo $row['email'];?><br>
                             <br>
                             <strong>Receiver Address : </strong>  <?php echo $row['raddress'];?>

                             <br>
                             <br>
                             <strong>Expected Date of Delivery : </strong>  <?php echo $row['edd'];?>
                         </div>
                     </div>
                 </div>
                 <div class="col-xs-12 col-md-4 col-lg-4 pull-right">
                     <div class="panel panel-default height" style="background-color:#e8fafc">
                         <div class="panel-heading" style="color:#fff; background-color:#148afd">Origin</div>
                         <div class="panel-body">
                              <strong>Sender Name : </strong> <?php echo $row['sname'];?> <br>
                            <br>


                             <strong>Location : </strong> <?php echo $row['location'];?><br>
                             <br>
                             <strong>Sender Address : </strong>  <?php echo $row['saddress'];?>

                             <br>
                             <br>
                             <strong>Shipment Date  : </strong>  <?php echo $row['shipdate'];?>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>



     <div class="row">
         <div class="col-md-12">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     <h3 class="text-center"><strong>History summary</strong></h3>
                 </div>
                 <div class="panel-body">
                     <div class="table-responsive">
                         <table class="table table-condensed">
                             <thead>

                                 <tr>

                                     <td><strong>Date</strong></td>
                                     <td class="text-center"><strong>Location</strong></td>
                                     <td class="text-center"><strong>Remark</strong></td>
                                     <td class="text-right"><strong>Status</strong></td>
                                 </tr>
                             </thead>
                             <tbody>

                                 	<?php

 						$sql= "SELECT * FROM history WHERE pid = '$tid'";
 			  $result = mysqli_query($link,$sql);
 			  if(mysqli_num_rows($result) > 0){
 				  while($row = mysqli_fetch_assoc($result)){



 				  ?>


                                 <tr>



                                     <td><?php echo $row['pdate'];?></td>
                                     <td class="text-center"><?php echo $row['location'];?></td>
                                     <td class="text-center"><?php echo $row['remark'];?></td>
                                     <td class="text-right"><?php echo $row['status'];?></td>





                                 </tr>
                                 <?php
           }
           }
 ?>
                             </tbody>
                         </table>
                     </div>
                 </div>
             </div>






             <?php

 			$sql= "SELECT * FROM track WHERE pid = '$tid'";
 			  $result = mysqli_query($link,$sql);
 			  if(mysqli_num_rows($result) > 0){
 				$row = mysqli_fetch_assoc($result);

 				$row['image'];
 				if(isset($row['image'])){

 					$image = $row['image'];
 				}

 			  }

 				  ?>


 <div class="container" align="center">

    <div align="center"><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Package Image</button></div>

   <!-- Modal -->
   <div class="modal fade" id="myModal" role="dialog">
     <div class="modal-dialog">

       <!-- Modal content-->
       <div class="modal-content">
         <div class="modal-header">
           <button type="button" class="close" data-dismiss="modal">&times;</button>
           <h4 class="modal-title"><?php echo $row['pname'];?></h4>
         </div>
         <div class="modal-body">
           <div align="center"><img src="../admin/pages/pimages/<?php echo $row['image']?>" width="300" height="300"></div>
         </div>
         <div class="modal-footer">
           <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
         </div>
       </div>

     </div>
   </div>

 </div>








         </div>
     </div>
 </div>

 <style>
 .height {
     min-height: 200px;
 }

 .icon {
     font-size: 47px;
     color: #5CB85C;
 }

 .iconbig {
     font-size: 77px;
     color: #5CB85C;
 }

 .table > tbody > tr > .emptyrow {
     border-top: none;
 }

 .table > thead > tr > .emptyrow {
     border-bottom: none;
 }

 .table > tbody > tr > .highrow {
     border-top: 3px solid;
 }
 </style>
 <br><br>

  <!--================================
         START FOOTER
     =================================-->

<?php include(TEMPLATE_FRONT . DS . "footer.php"); ?>
