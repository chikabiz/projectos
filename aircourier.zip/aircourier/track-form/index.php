<?php

require_once("config.php");


include "../config/database.php";

if(isset($_POST['submit'])){

	$tid = $_POST['tid'];




	if($tid == ""){

	echo "<script>alert('Please enter a tracking Number')</script>";

	}else{


		$sql= "SELECT * FROM track WHERE pid = '$tid'";
		$result = mysqli_query($link,$sql);
		if(mysqli_num_rows($result) > 0){
		  $row = mysqli_fetch_assoc($result);

		  $pid = $row['pid'];
		  if(isset($row['pid'])){

			  $pid = $row['pid'];



	if($tid == $pid){



	header("Location:track-form.php?track=$tid");

	}

	else{

		echo "<script>alert('No record for the track number')</script>";
	}

}

}

}
}



 ?>

 <!DOCTYPE html>
 <html lang="en-US">

 <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
 <head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="profile" href="http://gmpg.org/xfn/11">



 <link rel="shortcut icon" type="image/png" href="#"/>

 <title>Quik Courier & Logistics | Track form</title>
 <meta name='robots' content='max-image-preview:large' />
 <link rel='dns-prefetch' href='http://www.google.com/' />
 <style id='global-styles-inline-css' type='text/css'>
 body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
 </style>
 <link rel='stylesheet' id='contact-form-7-css'  href='../wp-content/plugins/contact-form-7/includes/css/styles42f0.css?ver=5.6.3' type='text/css' media='all' />
 <link rel='stylesheet' id='wpcf7-redirect-script-frontend-css'  href='../wp-content/plugins/wpcf7-redirect/build/css/wpcf7-redirect-frontend.min5b21.css?ver=6.0.2' type='text/css' media='all' />
 <link rel='stylesheet' id='bootstrap-css'  href='../wp-content/themes/courier/css/bootstrap.min5b21.css?ver=6.0.2' type='text/css' media='all' />
 <link rel='stylesheet' id='pherona-style-css'  href='../wp-content/themes/courier/style5b21.css?ver=6.0.2' type='text/css' media='all' />
 <link rel='stylesheet' id='owl-responsive-css'  href='../wp-content/themes/courier/css/responsive5b21.css?ver=6.0.2' type='text/css' media='all' />
 <link rel="canonical" href="../index.php" />


 </head>
 <body data-spy="scroll" data-offset="70" data-target="#main-nav" class="home page-template page-template-page-home page-template-page-home-php page page-id-5">




 <div id="ncf-overlay" class="d-md-none"></div>


 <div class='push_sidebar d-md-none'>
 <div class='push_sidebar_header text-right col-12 np'>
 <a class="close-sidebar" href="#"><span aria-hidden="true" style="font-size:28px;font-family:Arial;color:#555; padding-right:4px;display:block;position:relative;right:0px;font-weight:bold; cursor:pointer;">&times;</span></a>
 </div>

 <ul id="menu-main-menu" class="main-menu nav navbar-nav navbar-right">
	 <li id="menu-item-491" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="../index.php">HOME</a></li></li>

 </ul>

 </div>






 <header class="clearfix header">

 <div class="navbar navbar-default">
                    <div class="container">
 					<div class="row align-items-center">
                     <div class="col-3 d-block d-md-none">
                    <button type="button" class="navbar-toggle toggle-sidebar" data-toggle="collapse" data-target="#mobile-nav" aria-expanded="false">
 								<span class="icon-bar"></span>
 								<span class="icon-bar"></span>
 								<span class="icon-bar"></span>
 							</button>
                     </div>

 						<div class="col-6 col-lg-4 col-md-3 nmp m-center nlp">
 							<a href="../index.php" class="logo"><img src="../wp-content/uploads/2021/04/logo.png"></a>
 						</div>





 						<div class="col-lg-8 col-md-9 np navbar-expand-md">
 						<div class="collapse navbar-collapse justify-content-center d-md-flex" id="main-nav">
                                 <ul id="menu-main-menu-1" class="main-menu nav navbar-nav navbar-right">
 <li id="menu-item-491" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="../index.php">Home</a></li></li>

 </ul>                                </div>

 						</div>

 					</div>

 					</div>
 				</div>

 			</div>
 		</header>
<br><br>

		<section class="banner" style="background-image: url(../wp-content/uploads/2021/04/bg1.jpg);">
				<div class="container">
						<div class="row">
								<div class="col-lg-6 align-self-center">
										<div class="banner-text">
												<h1>Track your shipment at a go!</h1>

										</div>
								</div>
								<div class="col-lg-6">
										<div class="banner-form">


		<form action="index.php" method="post">

		<h2>Track Shipment</h2>
		<ul>
		<li class="full"><input type="text" name="tid" value="" size="40" class="wpcf7-form-control" placeholder="Enter Tracking Number" /></span></li>
		<li class="full"><button type="submit" name=submit class="btn wpcf7-submit">Track</button></li>
		</ul>
	</form>                            </div>
								</div>
						</div>
				</div>
		</section>

<br><br>
<br><br>



         <footer class="footer-section">
             <div class="footer-bottom">
                 <div class="container">
                     <div class="row d-flex justify-content-between">
                      <div class="col-lg-4 order-lg-1 m-center left-content">
                             <p>&copy; <script>document.write(new Date().getFullYear())</script> Quik Courier & Logistics. All Rights Reserved.</p>                        </div>
                     </div>
                 </div>
             </div>
         </footer>



 <script   type='text/javascript' src='../wp-content/plugins/contact-form-7/includes/swv/js/index42f0.js?ver=5.6.3' id='swv-js'></script>
 <script type='text/javascript' id='contact-form-7-js-extra'>
 /* <![CDATA[ */
 var wpcf7 = {"api":{"root":"https:\/\/www.courierservicesd.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
 /* ]]> */
 </script>
 <script   type='text/javascript' src='../wp-content/plugins/contact-form-7/includes/js/index42f0.js?ver=5.6.3' id='contact-form-7-js'></script>
 <script   type='text/javascript' src='../wp-includes/js/jquery/jquery.minaf6c.js?ver=3.6.0' id='jquery-core-js'></script>
 <script type='text/javascript' id='wpcf7-redirect-script-js-extra'>
 /* <![CDATA[ */
 var wpcf7r = {"ajax_url":"https:\/\/www.courierservicesd.com\/wp-admin\/admin-ajax.php"};
 /* ]]> */
 </script>
 <script   type='text/javascript' src='../wp-content/plugins/wpcf7-redirect/build/js/wpcf7r-fe4963.js?ver=1.1' id='wpcf7-redirect-script-js'></script>
 <script   type='text/javascript' src='../wp-content/themes/courier/js/bootstrap.min5b21.js?ver=6.0.2' id='bootstrap-js-js'></script>
 <script   type='text/javascript' src='../wp-content/themes/courier/js/jquery.magnific-popup.min5b21.js?ver=6.0.2' id='magnific-js-js'></script>
 <script   type='text/javascript' src='../wp-content/themes/courier/js/custom5b21.js?ver=6.0.2' id='custom-js-js'></script>
 <script   type='text/javascript' src='../www.google.com/recaptcha/api40a3.js?render=6LfmD2UaAAAAACFBFbTnQgsQctrh-0H1hRzlp6Eu&amp;ver=3.0' id='google-recaptcha-js'></script>
 <script   type='text/javascript' src='../wp-includes/js/dist/vendor/regenerator-runtime.min3937.js?ver=0.13.9' id='regenerator-runtime-js'></script>
 <script   type='text/javascript' src='../wp-includes/js/dist/vendor/wp-polyfill.min2c7c.js?ver=3.15.0' id='wp-polyfill-js'></script>
 <script type='text/javascript' id='wpcf7-recaptcha-js-extra'>
 /* <![CDATA[ */
 var wpcf7_recaptcha = {"sitekey":"6LfmD2UaAAAAACFBFbTnQgsQctrh-0H1hRzlp6Eu","actions":{"homepage":"homepage","contactform":"contactform"}};
 /* ]]> */
 </script>
 <script   type='text/javascript' src='../wp-content/plugins/contact-form-7/modules/recaptcha/index42f0.js?ver=5.6.3' id='wpcf7-recaptcha-js'></script>

 <script src="http://maps.google.com/maps/api/js?key=AIzaSyBJo7g-NOF3BxSdtc5kdtCUQC1hZ3E4jOo" type="text/javascript"></script>
 <script type="text/javascript">
 var locations = [
 ['Los Angeles, CA, USA', 34.0522342, -118.2436849],
 ['Orange County, CA, USA', 33.7174708, -117.8311428],
 ['San Diego, CA, USA', 32.715738, -117.1610838],
 ['Long Beach, CA, USA', 33.7700504, -118.1937395],
 ['Westlake Village, CA, USA', 34.1466467, -118.8073729],
 ['Thousand Oaks, CA, USA', 34.1705609, -118.8375937],
 ['Oceanside, CA, USA', 33.1958696, -117.3794834],
 ];
     var map = new google.maps.Map(document.getElementById('map'), {
       zoom:6,
       center: new google.maps.LatLng(34.052235, -118.243683),
       mapTypeId: google.maps.MapTypeId.ROADMAP
     });

     var infowindow = new google.maps.InfoWindow();

     var marker, i;

 var image = {
           url: 'https://www.quikcourrierlogistics.com/wp-content/uploads/2021/04/marker.svg',
 		  size: new google.maps.Size(33, 44),
         };

     for (i = 0; i < locations.length; i++) {
       marker = new google.maps.Marker({
         position: new google.maps.LatLng(locations[i][1], locations[i][2]),
         map: map,
 	    icon: image,
       });

       google.maps.event.addListener(marker, 'click', (function(marker, i) {
         return function() {
           infowindow.setContent(locations[i][0]);
           infowindow.open(map, marker);
         }
       })(marker, i));
     }
   </script>



 </body>

 </html>
