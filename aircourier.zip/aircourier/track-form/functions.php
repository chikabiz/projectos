<?php


function set_message($msg){

if(!empty($msg)){
  $_SESSION['message'] = $msg;
} else  {
  $msg = "";
}
}


function display_message(){
  if(isset($_SESSION['message'])){
      echo $_SESSION['message'];
      unset($_SESSION['message']);
    }
}




function escape_string($string){
global $connection;
return mysqli_real_escape_string($connection, $string);
}


function show_track(){

    if(isset($_POST['wpcargo-submit'])){

      $track = escape_string($_POST['tracking_number']);


      $query = query("SELECT * FROM users WHERE trackingno = '{$track}' ");
      confirm($query);

      if(mysqli_num_rows($query) == 0) {

        redirect("track-form/index.php");set_message("NO RESULTS FOUND");

    } else {
      redirect("track-form/track-form.php");
    }

    }

}

function query($sql){
global $connection;
return mysqli_query($connection, $sql);
}


//Database Main Object
function objDB(){

    $objDB = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if($objDB->connect_error){
      die("Connection not established");
    }

    return $objDB;
}


//format: 24 September, 2018
function cTime($timestamp){
    return date('j F, Y', $timestamp);
}



//checking user by email
function checkUserbytrackingno($track){

    //make database connection
    $connection = objDB();

     //make the statement
     $stmt = $connection->prepare(
            'SELECT * FROM users WHERE trackingno=?'
     );

     //bind the paramters
     $stmt->bind_param('s', $track);

     //execute
     $stmt->execute();


     //store the result
     $stmt->store_result();

     //return number of rows
     return $stmt->num_rows;
}




//redirection reuseable function
function redirect($file){
    header("Location:".URLROOT.'/'.$file);
}


//setting a msg
function setMsg($name, $value, $class = 'success'){
    if(is_array($value)){
        $_SESSION[$name] = $value;
    }else{
        $_SESSION[$name] = "<div class='alert alert-$class text-center'>$value<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'><sup>x</sup></span></button></div>";
    }

}

//getting a msg
function getMsg($name){
    if(isset($_SESSION[$name])){
        $session=$_SESSION[$name];
        unset($_SESSION[$name]);
        return $session;
    }
}


function getUserById($user_id){

    $connection = objDB();

    //Store them into database
     $stmt = $connection->prepare(
            'SELECT id FROM users WHERE trackingno=$track'
     );

     $stmt->bind_param('i', $user_id);

     $stmt->execute();

     //get the data
     $result = $stmt->get_result();

     return $result->fetch_object();
}



//If user is logged In
function isUserLoggedIn(){
    if(isset($_SESSION['user']) || isset($_COOKIE['user'])){
        return true;
    }else{
        return false;
    }
}



function connection(){

    $connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if($connection->connect_error){
      die("Connection not established");
    }

    return $connection;
}



function confirm($result){

global $connection;

if(!$result) {

die("QUERY FAILED " . mysqli_error($connection));
}
}
