<?php

$msg = "";
if(isset($_POST['submit'])){
  $name = $_POST['name'];
  $email=$_POST['email'];
  $subject=$_POST['subject'];
  $body=$_POST['message'];
  require "../admin/PHPMailer/PHPMailerAutoload.php";
  function smtpmailer($to, $from, $name, $subject, $body)
      {
  $mail = new PHPMailer;
  $mail->isSMTP();
  $mail->Host='quikcourierlogistics.com';
  $mail->Port = 465;
  $mail->SMTPAuth = true;
  $mail->SMTPSecure = 'ssl';
  $mail->Username = 'support@quikcourierlogistics.com';
  $mail->Password = 'adminemail123';
  $mail->IsHTML(true);
  $mail->From=$from;
  $mail->FromName=$name;
  $mail->Sender=$from;
  $mail->AddReplyTo($from, $name);
  $mail->Subject = $subject;
  $mail->Body = $body;
  $mail->AddAddress($to);
  if(!$mail->Send())
  {
    	echo "<script>window.location.href='".$bankurl."';</script>";
      $msg ="Something went wrong!";
      return $msg;
  }
  else
  {
      $msg = "Thanks for contacting us, we'll get back to you soon";
      return $msg;
  }
  }
$to = 'support@quikcourierlogistics.com';
$from = $email;
$name = $name;
$subj = "Form Submission: " .$subject;
$body = "<h2 align=center>Name: ".$name. "<br>Email: ".$email."<br>Message: " .$body."</h2>";
$msg=smtpmailer($to, $from, $name ,$subj, $body);
}

?>
