<!DOCTYPE html>
<html lang="en">

<head>
	<title>World Courier Express | Track page</title>
    <meta charset="UTF-8">

    <!-- viewport meta -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- owl carousel css -->
    <link rel="stylesheet" href="../wp-includes/user/css/owl.carousel.css"/>


    <!-- font icofont -->
    <link rel="stylesheet" href="../wp-includes/user/css/font-awesome.min.css"/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700|Montserrat:300,400,400i,700,900" rel="stylesheet">

    <!-- bootstrap -->
    <link rel="stylesheet" href="../wp-includes/user/css/bootstrap.min.css"/>

    <!-- animte css -->
    <link rel="stylesheet" href="../wp-includes/user/css/animate.css"/>

    <!-- camera css goes here -->
    <link rel="stylesheet" href="../wp-includes/user/css/camera.css">

    <!-- venobox css goes here -->
    <link rel="stylesheet" href="../wp-includes/user/css/venobox.css">

    <!-- style css -->
    <link rel="stylesheet" href="../wp-includes/user/css/style.css"/>
		<link rel="stylesheet" href="../wp-includes/user/css/style2.css"/>


    <!-- responsive css -->
    <link rel="stylesheet" href="../wp-includes/user/css/responsive.css">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/png" href="../wp-content/uploads/2021/04/logo.png"/>
</head>
<body class="service_page">


    <!-- start header -->
    <header>
        <!-- container start -->
        <div class="container">
            <!-- .row start -->
            <!-- <div class="row">
                <div class="tiny_header clearfix">
                    <div class="col-md-12">
                        <div class="tiny_header_wrapper">
                            <div class="header_info">
                                <ul>
                                    <li><a href="#">Faq</a></li>
                                    <li><a href="#">Help Desk</a></li>
                                    <li><a href="track_trace.php">Track Shipment</a></li>
                                </ul>
                            </div>

                            <div class="times">
                                <p><i class="fa fa-clock-o"></i> <span class="day">Sat - Thus</span>9 am - 6 pm</p>
                            </div>

                            <div class="social_links">
                                <ul>
                                    <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                                    <li><a href="#"><span class="fa fa-pinterest-p"></span></a></li>
                                    <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                                    <li><a href="#"><span class="fa fa-dribbble"></span></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- /.row end -->

            <!-- row start -->
            <div class="row">
                <div class="header_middle_wrapper clearfix">
                    <div class="col-md-3 xs_fullwidth col-xs-3">
                        <div class="logo_container">
                            <a href="index.php"><img style="height: 50px;" src="../wp-content/uploads/2021/04/logo.png" alt="Quik Courier & Logistics" data-alt-logo="../wp-content/uploads/2021/04/footer-logo-1.png"></a>
                        </div>
                    </div>

                    <div class="col-lg-5 xs_fullwidth col-xs-6 col-md-6 col-md-offset-0 col-lg-offset-1">
                      <div class="contact_info">
                          <!-- <div class="single_info_section">
                              <span class="fa fa-headphones v_middle"></span>
                              <div class="contact_numbers v_middle right_info">
                                  <p><a href="tel:+123445637894">+1234 (4563) 7894</a></p>
                                  <p><a href="tel:+123445637894">+1234 (4563) 7894</a></p>
                              </div>
                          </div> -->

                      </div>
                    </div>

                    <div class="col-md-3 xs_fullwidth col-xs-3 col-lg-2 col-lg-offset-1">
                        <a href="" class="trust_btn quote_btn">result page</a>
                    </div>
                </div>
            </div><!-- /.row end -->


        </div><!-- /.container end -->
    </header><!-- start header -->
    <!--================================
        END HEADER AREA
    =================================-->

    <!--================================
        START SLIDER AREA
    =================================-->
