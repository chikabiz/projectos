<footer class="boldSection gutter btSiteFooter btGutter ">
		<div class="port">
			<div class="boldRow">
				<div class="rowItem btFooterCopy col-md-6 col-sm-12 btTextLeft">
					<p class="copyLine">Copyright &copy World Courier Express Inc. &nbsp; &nbsp;|&nbsp; &nbsp; All rights reserved</p>
				</div><!-- /copy -->
				<div class="rowItem btFooterMenu col-md-6 col-sm-12 btTextRight">
				</div>
			</div><!-- /boldRow -->
		</div><!-- /port -->
	</footer>
</div><!-- /pageWrap -->

<!-- jquery latest version -->
<script src="../wp-includes/user/js/jquery-1.12.3.js"></script>

<!-- bootstrap js -->
<script src="../wp-includes/user/js/bootstrap.min.js"></script>

<!-- jquery easing 1.3 -->
<script src="../wp-includes/user/js/jquery.easing1.3.js"></script>

<!-- Owl carousel js-->
<script src="../wp-includes/user/js/owl.carousel.min.js"></script>

<!-- venobox js -->
<script src="../wp-includes/user/js/venobox.min.js"></script>

<!-- Isotope js-->
<script src="../wp-includes/user/js/isotope.js"></script>

<!-- Pakcery layout js-->
<script src="../wp-includes/user/js/packery.js"></script>

<!-- waypoint js -->
<script src="../wp-includes/user/js/waypoints.min.js"></script>

<!-- google map js -->
<script src="http://maps.googleapis.com/maps/api/js"></script>

<!-- smoothscroll js -->
<script src="../wp-includes/user/js/jqury.smooth-scroll.min.js"></script>

<!-- jquery camera slider js -->
<script src="../wp-includes/user/js/jquery.camera.min.js"></script>
<!-- Counter up -->
<script src="../wp-includes/user/js/jquery.counterup.js"></script>

<!-- Waypoint -->
<script src="../wp-includes/user/js/waypoints.min.js"></script>

<!-- Main js -->
<script src="../wp-includes/user/js/main.js"></script>

		</body>
</html>
