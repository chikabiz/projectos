<?php

function setMsg($name, $value, $class = 'success'){
    if(is_array($value)){
        $_SESSION[$name] = $value;
    }else{
        $_SESSION[$name] = "<div class='alert alert-$class text-center'>$value</div>";
    }
}

//getting a msg
function getMsg($name){
    if(isset($_SESSION[$name])){
        $session=$_SESSION[$name];
        unset($_SESSION[$name]);
        return $session;
    }
}

use PHPMailer\PHPMailer\PHPMailer;

//PHPMailer Object
if(isset($_POST['submit'])){

	$name = $_POST['name'];
	$email=$_POST['email'];
	$subject=$_POST['subject'];
	$body=$_POST['message'];

	require_once "PHPMailer.php";
	require_once "SMTP.php";
	require_once "Exception.php";


	$mail = new PHPMailer();

	$mail->isSMTP();
	$mail->Host='smtp.gmail.com';
	$mail->Port = 465;
	$mail->SMTPAuth = true;
	$mail->SMTPSecure = 'ssl';
	$mail->username='deliveryexpressconsultant@gmail.com';
	$mail->password='administrator123';

	$mail->setFrom($email, $name);
	$mail->addAddress('deliveryexpressconsultant@gmail.com');


	$mail->isHTML(true);
	$mail->Subject = "Form Submission:" .$subject;
	$mail->Body = "<h2 align=center>Name: ".$name. "<br>Email: ".$email."<br>Message: " .$message."</h2>";

	if(!$mail->send()){
		setMsg('msg', 'Something went wrong. Please try again.', 'danger');
	}else{

		setMsg('msg', 'Thanks for contacting us. We will get back to you soon.', 'success');
	}
}

?>
