<!DOCTYPE html>
<html lang="en-US">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">



	    <!--[if lt IE 9]>
	     <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	     <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	   <![endif]-->


<link rel="shortcut icon" type="image/png" href="#"/>

<title>Quik Courier & Logistics</title>
<meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='http://www.google.com/' />
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='wp-content/plugins/contact-form-7/includes/css/styles42f0.css?ver=5.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='wpcf7-redirect-script-frontend-css'  href='wp-content/plugins/wpcf7-redirect/build/css/wpcf7-redirect-frontend.min5b21.css?ver=6.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='wp-content/themes/courier/css/bootstrap.min5b21.css?ver=6.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='pherona-style-css'  href='wp-content/themes/courier/style5b21.css?ver=6.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='owl-responsive-css'  href='wp-content/themes/courier/css/responsive5b21.css?ver=6.0.2' type='text/css' media='all' />
<link rel="canonical" href="index.html" />


		<script>
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','../www.google-analytics.com/analytics.js','ga');
			ga('create', 'UA-38443150-4', 'auto');
			ga('send', 'pageview');
		</script>



<script type="text/javascript" src="../cdn.callrail.com/companies/541983303/164a89de765124a3723f/12/swap.js"></script>

<script async src="https://www.googletagmanager.com/gtag/js?id=AW-10933208063"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-10933208063');
</script>



<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PV6C49H');</script>


<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PV6C49H" height="0" width="0"></iframe></noscript>




<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P8P6ZC');</script>


</head>
<body data-spy="scroll" data-offset="70" data-target="#main-nav" class="home page-template page-template-page-home page-template-page-home-php page page-id-5">




<div id="ncf-overlay" class="d-md-none"></div>


<div class='push_sidebar d-md-none'>
<div class='push_sidebar_header text-right col-12 np'>
<a class="close-sidebar" href="#"><span aria-hidden="true" style="font-size:28px;font-family:Arial;color:#555; padding-right:4px;display:block;position:relative;right:0px;font-weight:bold; cursor:pointer;">&times;</span></a>
</div>

<ul id="menu-main-menu" class="main-menu nav navbar-nav navbar-right"><li id="menu-item-491" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#pickup-delivery">Services</a></li></li>
<li id="menu-item-492" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#about-us">About Us</a></li></li>
<li id="menu-item-490" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#how-it-works">How It Works</a></li></li>
<li id="menu-item-489" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#testimonials">Testimonials</a></li></li>
<li id="menu-item-488" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#why-choose-us">Why Us</a></li></li>
<li id="menu-item-741" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="nav-link" href="track-form" >Track Shipment</a></li></li>
<li id="menu-item-15" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#contact-us">Contact Us</a></li></li>
</ul>

</div>






<header class="clearfix header">


<div class="top-bar">
                    <div class="container">
                        <div class="topbar-content">
                            <div class="left-content m-center">
                                <p>Courier Services around the world.</p>                            </div>
                            <div class="right-content m-center">
                                 <p><i class="fa fa-phone"></i>  24/7 Pick Up &amp; Delivery Service </p>                            </div>
                        </div>
                    </div>
                </div>


<div class="navbar navbar-default">
                   <div class="container">
					<div class="row align-items-center">
                    <div class="col-3 d-block d-md-none">
                   <button type="button" class="navbar-toggle toggle-sidebar" data-toggle="collapse" data-target="#mobile-nav" aria-expanded="false">
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
                    </div>

						<div class="col-6 col-lg-4 col-md-3 nmp m-center nlp">
							<a href="index.html" class="logo"><img src="wp-content/uploads/2021/04/logo.png"></a>
						</div>

                        <div class="col-3 text-right d-block d-md-none m-phone">
							<a href="tel:818-384-2802"><i class="fa fa-phone"></i> </a>
                    </div>



						<div class="col-lg-8 col-md-9 np navbar-expand-md">
						<div class="collapse navbar-collapse justify-content-center d-md-flex" id="main-nav">
                                <ul id="menu-main-menu-1" class="main-menu nav navbar-nav navbar-right"><li id="menu-item-491" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#pickup-delivery">Services</a></li></li>
<li id="menu-item-492" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#about-us">About Us</a></li></li>
<li id="menu-item-490" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#how-it-works">How It Works</a></li></li>
<li id="menu-item-489" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#testimonials">Testimonials</a></li></li>
<li id="menu-item-488" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#why-choose-us">Why Us</a></li></li>
<li id="menu-item-741" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="nav-link" href="track-form" >Track Shipment</a></li></li>
<li id="menu-item-15" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#contact-us">Contact Us</a></li></li>
</ul>                                </div>

						</div>

					</div>

					</div>
				</div>

			</div>
		</header>

<div class="clearfix"></div>




            <section class="banner" style="background-image: url(wp-content/uploads/2021/04/bg1.jpg);">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 align-self-center">
                            <div class="banner-text">
                                <h1>All around the world Go-To Delivery Service.</h1>
<p>24/7, Fast, Secure, Local Pick Up and Delivery!</p>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="banner-form">
                                <div role="form" class="wpcf7" id="wpcf7-f539-p5-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="https://www.quikcourierlogistics.com/#wpcf7-f539-p5-o1" method="post" class="wpcf7-form init" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="539" />
<input type="hidden" name="_wpcf7_version" value="5.6.3" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f539-p5-o1" />
<input type="hidden" name="_wpcf7_container_post" value="5" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
<input type="hidden" name="_wpcf7_recaptcha_response" value="" />
</div>
<h2>Quick Quote</h2>
<p><span class="wpcf7-form-control-wrap" data-name="delivery-type"><span class="wpcf7-form-control wpcf7-radio"><span class="wpcf7-list-item first"><label><input type="radio" name="delivery-type" value="Select:" checked="checked" /><span class="wpcf7-list-item-label">Select:</span></label></span><span class="wpcf7-list-item"><label><input type="radio" name="delivery-type" value="Rush" /><span class="wpcf7-list-item-label">Rush</span></label></span><span class="wpcf7-list-item"><label><input type="radio" name="delivery-type" value="Regular" /><span class="wpcf7-list-item-label">Regular</span></label></span><span class="wpcf7-list-item last"><label><input type="radio" name="delivery-type" value="Overnight" /><span class="wpcf7-list-item-label">Overnight</span></label></span></span></span></p>
<ul>
<li class="full"><span class="wpcf7-form-control-wrap" data-name="your-name"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Your Name" /></span></li>
<li id="date">
                                            <span class="wpcf7-form-control-wrap" data-name="pickup-date"><input type="text" name="pickup-date" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Pick Up Date*" /></span> <i class="fa fa-calendar"></i>
                                        </li>
<li>
                                            <span class="wpcf7-form-control-wrap" data-name="weight"><input type="text" name="weight" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Weight* (lbs)" /></span>
                                        </li>
<li>
                                            <span class="wpcf7-form-control-wrap" data-name="pickup-zipcode"><input type="text" name="pickup-zipcode" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Pick Up Zip Code*" /></span>
                                        </li>
<li>
                                            <span class="wpcf7-form-control-wrap" data-name="delivery-zipcode"><input type="text" name="delivery-zipcode" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Delivery Zip Code*" /></span>
                                        </li>
<li>
                                           <span class="wpcf7-form-control-wrap" data-name="your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Your Email" /></span>
                                        </li>
<li><span class="wpcf7-form-control-wrap" data-name="your-phone"><input type="tel" name="your-phone" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel" aria-required="true" aria-invalid="false" placeholder="Your Phone Number" /></span></li>
<li class="full">
                                           <span class="wpcf7-form-control-wrap" data-name="your-message"><textarea name="your-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Description"></textarea></span>
                                        </li>
<li class="full"><button type="submit" class="btn wpcf7-submit">Get Quote</button></li>
</ul>
<div class="wpcf7-response-output" aria-hidden="true"></div></form></div>                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="service-section" id="pickup-delivery">
                <div class="container">
                    <div class="section-title">
                        <p><strong>OUR SERVICES</strong></p>
<h2>30+ Years of Delivery Service</h2>
<p>We take pride in getting your parcels and documents delivered safely, securely, on time, and without hassle.</p>
                    </div>
                    <ul>


                          <li>
                            <div class="service">
                                <div class="icon">
                                    <img src="wp-content/uploads/2021/04/icon1.png">
                                </div>
                               <h3>ASAP Pick up &amp; Delivery</h3>
<p>Need it picked up and delivered As Soon As Possible? We got your covered with our ASAP service.</p>
                            </div>
                        </li>


                          <li>
                            <div class="service">
                                <div class="icon">
                                    <img src="wp-content/uploads/2021/04/icon4.png">
                                </div>
                               <h3>Eco Pick Up &amp; Delivery</h3>
<p>Economy Courier / Messenger Service, Call us today to schedule your pick up/delivery at reduced rates.</p>
                            </div>
                        </li>


                          <li>
                            <div class="service">
                                <div class="icon">
                                    <img src="wp-content/uploads/2021/04/icon3.png">
                                </div>
                               <h3>Rush or Same-Day Service</h3>
<p>We offer Same-Day, Overnight, Economy, ASAP and Rush Service. Call us now for pricing and details.</p>
                            </div>
                        </li>


                          <li>
                            <div class="service">
                                <div class="icon">
                                    <img src="wp-content/uploads/2021/04/icon2.png">
                                </div>
                               <h3>Overnight Delivery</h3>
<p>Need it delivered overnight? We got your covered, call us now for an instant price quote.</p>
                            </div>
                        </li>




                    </ul>
                </div>
            </section>

            <section class="about-section" id="about-us">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="about-thumb">

                              <div class="video-main">

                                    <div class="shap shap-1"></div>
                                    <div class="shap shap-2"></div>
                                    <div class="shap shap-3"></div>

                                <p class="video-link" data-lity><i class="fa fa-play"></i> </p>



                            </div>





                                <img src="wp-content/uploads/2021/04/about-thumb.jpg">
                            </div>
                        </div>
                        <div class="col-lg-6 align-self-center">
                            <div class="section-title">
                                <p><strong>ABOUT US</strong></p>
<h2>We Are More Than Just A Delivery Service.</h2>
                               <p>Quik Courier & Logistics is considered to be the most reliable and dependable of all the messenger services. We offer same day delivery service and take great pride in making sure you receive the best possible service.</p>
                                <a href="track-form"><i class="fa " aria-hidden="true"></i>  Click to Track Shipment</a>                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="brand-section">
                <div class="container">
                    <hr>
                    <div class="section-title">
                        <p><strong>TRUSTED BY THESE ORGANIZATIONS</strong></p>
                    </div>
                    <div class="brand-slider">



                         <div class="brand">
                            <img src="wp-content/uploads/2021/04/1-1.png">
                        </div>



                         <div class="brand">
                            <img src="wp-content/uploads/2021/04/2-1.png">
                        </div>



                         <div class="brand">
                            <img src="wp-content/uploads/2021/04/3-1.png">
                        </div>



                         <div class="brand">
                            <img src="wp-content/uploads/2021/04/4-1.png">
                        </div>



                         <div class="brand">
                            <img src="wp-content/uploads/2021/04/5-1.png">
                        </div>





                    </div>
                </div>
            </section>

            <section class="works-section" id="how-it-works">
                <div class="container">
                    <div class="section-title white">
                        <p><strong>WORKING WITH US</strong></p>
<h2>How It Works</h2>
                    </div>
                    <ul>






                        <li>
                            <div class="work">
                                <div class="icon">
                                    <img src="wp-content/uploads/2021/04/12.png">
                                </div>
                                 <h3>Call or Book Online</h3>
<p>We’re the fastest and trusted courier services in Greater San Diego County! With multiple offices in San Diego County, we have a courier/messenger available for pick up/drop off delivery, minutes from you.</p>
                            </div>
                        </li>








                        <li>
                            <div class="work">
                                <div class="icon">
                                    <img src="wp-content/uploads/2021/04/13.png">
                                </div>
                                 <h3>Pickup</h3>
<p>Our driver will arrive at your specified pick-up locations and pick-up the items to be delivered.</p>
                            </div>
                        </li>








                        <li>
                            <div class="work">
                                <div class="icon">
                                    <img src="wp-content/uploads/2021/04/14.png">
                                </div>
                                 <h3>Speed</h3>
<p>Timeliness is next to Godliness! We offer 100% customer satisfaction and operate reliable transportation that is maintained and upgraded throughout the years.</p>
                            </div>
                        </li>








                        <li>
                            <div class="work">
                                <div class="icon">
                                    <img src="wp-content/uploads/2021/04/15.png">
                                </div>
                                 <h3>Delivered</h3>
<p>Your package will be delivered per your drop-off location (delivery address) on-time, every time.</p>
                            </div>
                        </li>






                    </ul>
                </div>
            </section>

            <section class="testimonial-section" id="testimonials">
                <div class="container">
                    <div class="section-title">
                        <p><strong>Testimonials</strong></p>
<h2>What Our Clients</h2>
<p>See why thousands of companies are already using us for their go-to courier messenger delivery service today.</p>
                    </div>
                    <div class="slider-content">
                        <div class="testimonial-slider">



            <div class="testimonial">
                                <div class="icon">
                                    <img src="wp-content/themes/courier/images/others/icon11.png" alt="Image">
                                </div>
                                <ul>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                </ul>
                                <p>We needed a rush delivery service during rush-hour traffic from San Diego to Los Angeles and everywhere in between, just thinking about it made me dizzy… We found you guys through an advert and decided to give you guys a try, well, we glad we did! Our documents were rush delivered 15 minutes before schedule (which is awesome!) and the rate was great too. We truly admire your dedication to providing amazing service. Thank you!</p>
                                <h6>William Sharizian</h6>
                            </div>





                        </div>
                    </div>
                </div>
            </section>

            <section class="choose-section" id="why-choose-us">
                <div class="container">
                    <div class="section-title">

                    <p><strong>Why Choose Us</strong></p>
<h2>State-of-the-art Courier &amp; Messenger Service At Your Fingertips</h2>

                    </div>

                    <ul>




                          <li>
                            <div class="choose-text">
                                <div class="icon">
                                    <img src="wp-content/uploads/2021/04/icon5.png">
                                </div>
                                <div class="text">

                                  <h3>Fast</h3>
<p>We&#8217;re the fastest and trusted courier services in Greater San Diego California! With multiple offices in California, we have a courier/messenger available for pick up/drop off delivery, minutes from you.</p>
                                </div>
                            </div>
                        </li>






                          <li>
                            <div class="choose-text">
                                <div class="icon">
                                    <img src="wp-content/uploads/2021/04/icon6.png">
                                </div>
                                <div class="text">

                                  <div class="text">
<h3>Trusted &amp; Secure</h3>
<p>Reliability is absolutely everything when it comes to courier/delivery services. With over 30+ years in the courier business, we&#8217;re the trusted courier service in Greater San Diego California! Try us and see for yourself.</p>
</div>
                                </div>
                            </div>
                        </li>






                          <li>
                            <div class="choose-text">
                                <div class="icon">
                                    <img src="wp-content/uploads/2021/04/icon7.png">
                                </div>
                                <div class="text">

                                  <div class="text">
<h3>On Time</h3>
<p>Timeliness is next to Godliness! We offer 100% customer satisfaction and operate reliable transportation that is maintained and upgraded throughout the years.</p>
</div>
                                </div>
                            </div>
                        </li>






                          <li>
                            <div class="choose-text">
                                <div class="icon">
                                    <img src="wp-content/uploads/2021/04/icon8.png">
                                </div>
                                <div class="text">

                                  <div class="text">
<h3>A+ BBB Rated Couriers</h3>
<p>We are accredited by a wide range of industry associations and are proud of our A+ BBB rating and hundreds of online customer reviews.</p>
</div>
                                </div>
                            </div>
                        </li>






                          <li>
                            <div class="choose-text">
                                <div class="icon">
                                    <img src="wp-content/uploads/2021/04/icon9.png">
                                </div>
                                <div class="text">

                                  <div class="text">
<h3>100% Licensed/ Bonded/Insured</h3>
<p>We are Licensed, Bonded &amp; Insured. Call us with confidence, we got you covered.</p>
</div>
                                </div>
                            </div>
                        </li>






                          <li>
                            <div class="choose-text">
                                <div class="icon">
                                    <img src="wp-content/uploads/2021/04/icon10.png">
                                </div>
                                <div class="text">

                                  <div class="text">
<h3>Local and International Delivery</h3>
<p>We offer both Local and International Courier/Messenger service. Call us today for immediate service.</p>
</div>
                                </div>
                            </div>
                        </li>








                    </ul>
                </div>
            </section>

            <section class="contact-section" id="contact-us">
                <div class="container">
                    <div class="section-title">
                        <h2>Contact Us</h2>
<p>Quik Courier & Logistics welcomes your general inquiries, pricing requests and suggestions.</p>
                    </div>


                    <div class="row">
                        <div class="col-lg-10 offset-lg-1 col-xl-8 offset-xl-2">
                            <div role="form" class="wpcf7" id="wpcf7-f538-p5-o2" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="template/contact.php" method="post" class="wpcf7-form" >

<label>Name:*</label><input type="text" name="name" value="" size="40" class="wpcf7-form-control" required placeholder="Your Name" /></span></li>
<label>Email:*</label><input type="email" name="email" value="" size="40" class="wpcf7-form-control" required placeholder="Your Email" /></span></li>
<label>Subject:</label><input type="text" name="subject" value="" size="40" class="wpcf7-form-control" placeholder="Subject" /></span></li>
<label>Comment:</label><textarea name="message" cols="40" rows="10" class="wpcf7-form-control" required placeholder="Your Concerns"></textarea></span></li>
<button type="submit" class="btn wpcf7-submit">Get Quote</button></li>
</form></div>                        </div>
                    </div>
                </div>
            </section>

        </div>









        <footer class="footer-section">
            <div class="footer-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="footer-widget">
                               <a href="index.html" class="logo"><img src="wp-content/uploads/2021/04/footer-logo-1.png"></a>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="footer-widget address-widget">
                                 <ul>
                                    <li>
                                        <div class="icon"><i class="fa fa-mail" aria-hidden="true"></i></div>
                                        <div class="text">
                                          support@quikcourierlogistics.com </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="footer-widget address-widget">
                                 <ul>
                                    <li>
                                        <div class="icon"><i class="fa fa-calendar-o" aria-hidden="true"></i></div>
                                        <div class="text">
                                            <p>Operating Hours</p>
<p>MON – FRI: 8AM – 5PM</p>                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="footer-widget address-widget">
                                 <ul>
                                    <li>
                                        <div class="icon"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
                                        <div class="text">
                                             <p>San Diego County, California & Beyond</p>
<p></p>                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <div class="container">
                    <div class="row d-flex justify-content-between">

                     <div class="col-lg-8 order-lg-2 m-center right-content">
                           <ul id="menu-main-menu-2" class="footer-menu"><li id="menu-item-491" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#pickup-delivery">Services</a></li></li>
<li id="menu-item-492" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#about-us">About Us</a></li></li>
<li id="menu-item-490" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#how-it-works">How It Works</a></li></li>
<li id="menu-item-489" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#testimonials">Testimonials</a></li></li>
<li id="menu-item-488" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#why-choose-us">Why Us</a></li></li>
<li id="menu-item-741" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="nav-link" href="track-form" >Track Shipment</a></li></li>
<li id="menu-item-15" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="nav-link"  href="#contact-us">Contact Us</a></li></li>
</ul>                        </div>


                        <div class="col-lg-4 order-lg-1 m-center left-content">
                            <p>&copy; <script>document.write(new Date().getFullYear())</script> Quik Courier & Logistics. All Rights Reserved.</p>                        </div>

                    </div>
                </div>
            </div>
        </footer>


				    </div>




<script   type='text/javascript' src='wp-content/plugins/contact-form-7/includes/swv/js/index42f0.js?ver=5.6.3' id='swv-js'></script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/www.courierservicesd.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script   type='text/javascript' src='wp-content/plugins/contact-form-7/includes/js/index42f0.js?ver=5.6.3' id='contact-form-7-js'></script>
<script   type='text/javascript' src='wp-includes/js/jquery/jquery.minaf6c.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' id='wpcf7-redirect-script-js-extra'>
/* <![CDATA[ */
var wpcf7r = {"ajax_url":"https:\/\/www.courierservicesd.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script   type='text/javascript' src='wp-content/plugins/wpcf7-redirect/build/js/wpcf7r-fe4963.js?ver=1.1' id='wpcf7-redirect-script-js'></script>
<script   type='text/javascript' src='wp-content/themes/courier/js/bootstrap.min5b21.js?ver=6.0.2' id='bootstrap-js-js'></script>
<script   type='text/javascript' src='wp-content/themes/courier/js/jquery.magnific-popup.min5b21.js?ver=6.0.2' id='magnific-js-js'></script>
<script   type='text/javascript' src='wp-content/themes/courier/js/custom5b21.js?ver=6.0.2' id='custom-js-js'></script>
<script   type='text/javascript' src='../www.google.com/recaptcha/api40a3.js?render=6LfmD2UaAAAAACFBFbTnQgsQctrh-0H1hRzlp6Eu&amp;ver=3.0' id='google-recaptcha-js'></script>
<script   type='text/javascript' src='wp-includes/js/dist/vendor/regenerator-runtime.min3937.js?ver=0.13.9' id='regenerator-runtime-js'></script>
<script   type='text/javascript' src='wp-includes/js/dist/vendor/wp-polyfill.min2c7c.js?ver=3.15.0' id='wp-polyfill-js'></script>
<script type='text/javascript' id='wpcf7-recaptcha-js-extra'>
/* <![CDATA[ */
var wpcf7_recaptcha = {"sitekey":"6LfmD2UaAAAAACFBFbTnQgsQctrh-0H1hRzlp6Eu","actions":{"homepage":"homepage","contactform":"contactform"}};
/* ]]> */
</script>
<script   type='text/javascript' src='wp-content/plugins/contact-form-7/modules/recaptcha/index42f0.js?ver=5.6.3' id='wpcf7-recaptcha-js'></script>

<script src="http://maps.google.com/maps/api/js?key=AIzaSyBJo7g-NOF3BxSdtc5kdtCUQC1hZ3E4jOo" type="text/javascript"></script>
<script type="text/javascript">
var locations = [
['Los Angeles, CA, USA', 34.0522342, -118.2436849],
['Orange County, CA, USA', 33.7174708, -117.8311428],
['San Diego, CA, USA', 32.715738, -117.1610838],
['Long Beach, CA, USA', 33.7700504, -118.1937395],
['Westlake Village, CA, USA', 34.1466467, -118.8073729],
['Thousand Oaks, CA, USA', 34.1705609, -118.8375937],
['Oceanside, CA, USA', 33.1958696, -117.3794834],
];
    var map = new google.maps.Map(document.getElementById('map'), {
      zoom:6,
      center: new google.maps.LatLng(34.052235, -118.243683),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    var infowindow = new google.maps.InfoWindow();

    var marker, i;

var image = {
          url: 'https://www.quikcourrierlogistics.com/wp-content/uploads/2021/04/marker.svg',
		  size: new google.maps.Size(33, 44),
        };

    for (i = 0; i < locations.length; i++) {
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map,
	    icon: image,
      });

      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          infowindow.setContent(locations[i][0]);
          infowindow.open(map, marker);
        }
      })(marker, i));
    }
  </script>



</body>

</html>
